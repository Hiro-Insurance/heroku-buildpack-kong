
int fixturedep_fn() {
   return 0;
}
